  <hr>

      <footer>
        <div class="foot_center3"><p>Copyright &copy; 2022 wichita Grad School CS </p>
		<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbspProgrammed by:  Group Girls </p>
		</div>
      </footer>