	  <hr>

      <footer>
        <div class="foot_center"><p>Copyright &copy; 2022 wichita Grad School CS</p>
		<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbspProgrammed by: Group Girls :-P</p>
		</div>
      </footer>